package roman.pidkostelny.dealer.specification;

import org.springframework.data.jpa.domain.Specification;
import roman.pidkostelny.dealer.dto.request.CountyrFilterRequest;
import roman.pidkostelny.dealer.dto.request.SongsFilterRequest;
import roman.pidkostelny.dealer.entity.Country;
import roman.pidkostelny.dealer.entity.Songs;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

public class CountrySpecification implements Specification<Country> {
    private CountyrFilterRequest filter;

    public CountrySpecification(CountyrFilterRequest filter) {
        this.filter = filter;
    }

    private String value;

    public CountrySpecification(String value) {
        this.value = value;
    }

    private Predicate findByName(Root<Country> root, CriteriaBuilder criteriaBuilder) {
        return criteriaBuilder.like(root.get("Name"), value);
    }


    @Override
    public Predicate toPredicate(Root<Country> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
        return criteriaBuilder.or(findByName(root, criteriaBuilder));
    }

}
