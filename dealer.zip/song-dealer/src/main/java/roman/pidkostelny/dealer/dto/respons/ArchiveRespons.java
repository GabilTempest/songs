package roman.pidkostelny.dealer.dto.respons;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import roman.pidkostelny.dealer.entity.Archive;

@Getter
@Setter
@NoArgsConstructor
public class ArchiveRespons {
    private Long id;

    private String name;

    private String url;

    private String bame;


    public ArchiveRespons(Archive genre) {
        id = genre.getId();
        name = genre.getName();
        url = genre.getUrl();
        bame = genre.getBame();

    }

}
