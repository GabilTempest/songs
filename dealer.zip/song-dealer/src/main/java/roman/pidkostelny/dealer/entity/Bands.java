package roman.pidkostelny.dealer.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
//@ToString

@Entity
public class Bands {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long year;

    @Column(unique = true)
    private String name;

    private String genreName;

    private String alive;



//    @ManyToMany(mappedBy = "bands")
//    private List<Archive> genres = new ArrayList<>();


    @ManyToMany(mappedBy = "bands")
    private List<Songs> songs = new ArrayList<>();


    @ManyToOne
    private Country country;

    @ManyToOne
    private Person person;


}
