package roman.pidkostelny.dealer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;
import roman.pidkostelny.dealer.dto.request.ArchiveRequest;
import roman.pidkostelny.dealer.dto.request.SongsRequest;
import roman.pidkostelny.dealer.dto.respons.DataResponse;
import roman.pidkostelny.dealer.dto.respons.ArchiveRespons;
import roman.pidkostelny.dealer.entity.Archive;
import roman.pidkostelny.dealer.exception.WrongInp;
import roman.pidkostelny.dealer.service.ArchiveService;

import javax.validation.Valid;

@RestController
@RequestMapping("/genre")
public class ArchiveController {
    @Autowired
    private ArchiveService archiveService;

    @GetMapping
    public DataResponse<ArchiveRespons> getGenre(@RequestParam(required = false) String value,
                                                 @RequestParam Integer page,
                                                 @RequestParam Integer size,
                                                 @RequestParam String sortFieldName,
                                                 @RequestParam Sort.Direction direction) {
        System.out.println("GET ALL Archives");
        return archiveService.findAll(value, page, size, sortFieldName, direction);
    }


    @PutMapping
//    @PreAuthorize("hasAuthority('ADMIN')")
    public ArchiveRespons Update(@RequestParam Long id, @RequestBody ArchiveRequest archiveRequest) throws WrongInp {
        return archiveService.update(id, archiveRequest);
    }

    @GetMapping("/one")
    public ArchiveRespons findOne(@RequestParam Long id) throws WrongInp {
        return archiveService.findOneById(id);
    }


    @PostMapping
    public Long save(@RequestBody @Valid ArchiveRequest archiveRequest) {
        System.out.println("SAVE ARCHIVES IN DB with first name -> " + archiveRequest.getName());
        return archiveService.save(archiveRequest);
    }

    @GetMapping("/getOneById")
    public ArchiveRespons findOneById(@RequestParam Long id) throws WrongInp {
        return archiveService.findOneById(id);
    }

    @DeleteMapping("/{id}")
//    @PreAuthorize("hasAnyAuthority('ADMIN')")
    public void search(@PathVariable Long id) throws WrongInp {
        System.out.println("Delete archive by id " + id);
        archiveService.delete(id);
    }

    @GetMapping("/{id}")
//    @PreAuthorize("hasAuthority('ADMIN')")
    public Archive getgenreById(@PathVariable Long id) throws WrongInp {
        System.out.println("Get arhive by id : " + id);
        return archiveService.findOne(id);
    }


}