package roman.pidkostelny.dealer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import roman.pidkostelny.dealer.entity.Archive;

@Repository
public interface ArchiveRepository extends JpaRepository<Archive, Long>, JpaSpecificationExecutor<Archive> {
    //
//    @Query("select c from Archive c join fetch c.bands where c.name = :cName")
//    Archive findByNameLike(@Param("cName") String name);
}
