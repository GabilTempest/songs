package roman.pidkostelny.dealer.dto.request;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter

public class CountyrFilterRequest {

    private String name;

    private List<Long> countryId = new ArrayList<>();

    private PaginationRequest paginationRequest;
}
