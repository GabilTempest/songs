package roman.pidkostelny.dealer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import roman.pidkostelny.dealer.entity.Bands;
import roman.pidkostelny.dealer.entity.Country;

@Repository
public interface BandsRepository extends JpaRepository<Bands, Long>, JpaSpecificationExecutor<Bands> {
    @Query("select c from Bands c join fetch c.country where c.name = :cName")
    Country findByNameLike(@Param("cName") String name);

    @Query("select c from Bands c join fetch c.country where c.name = :cName")
    Country findAllByGenreName(@Param("cName") String name);
}
