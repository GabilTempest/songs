package roman.pidkostelny.dealer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import roman.pidkostelny.dealer.dto.request.ArchiveRequest;

import roman.pidkostelny.dealer.dto.request.SongsRequest;
import roman.pidkostelny.dealer.dto.respons.DataResponse;
import roman.pidkostelny.dealer.dto.respons.ArchiveRespons;

import roman.pidkostelny.dealer.entity.Archive;

import roman.pidkostelny.dealer.entity.Songs;
import roman.pidkostelny.dealer.exception.WrongInp;
import roman.pidkostelny.dealer.repository.ArchiveRepository;
import roman.pidkostelny.dealer.specification.ArchiveSpecification;

import java.util.stream.Collectors;

@Service
public class ArchiveService {

    @Autowired
    private ArchiveRepository archiveRepository;


//    public ArchiveRespons save(ArchiveRequest archiveRequest) throws WrongInp {
//        return new ArchiveRespons(genreRequestToGenre(null, archiveRequest));
//    }

    public Long save(ArchiveRequest archiveRequest) {
        Archive archive = new Archive();
        archive.setName(archiveRequest.getName());
        archive.setUrl(archiveRequest.getUrl());
        archive.setBame(archiveRequest.getBame());
        archive = archiveRepository.save(archive);
        return archive.getId();
    }

    public ArchiveRespons update(Long id, ArchiveRequest archiveRequest) throws WrongInp {
        return new ArchiveRespons(genreRequestToGenre(findOne(id), archiveRequest));
    }

    public Archive findOne(Long id) throws WrongInp {
        return archiveRepository.findById(id).orElseThrow(() -> new WrongInp("Archive with id " + id + " not exists"));
    }

    private Archive genreRequestToGenre(Archive genre, ArchiveRequest request) {
        if (genre == null) {
            genre = new Archive();
        }
        genre.setName(request.getName());
        genre.setUrl(request.getUrl());
        genre.setBame(request.getBame());
        return archiveRepository.save(genre);
    }

    public void delete(Long id) throws WrongInp {
        archiveRepository.delete(findOne(id));
    }


    public ArchiveRespons findOneById(Long id) throws WrongInp {
        return new ArchiveRespons(findOne(id));
    }

    public DataResponse<ArchiveRespons> findAll(String value, Integer page, Integer size, String fieldName, Sort.Direction direction) {
        Sort sort = Sort.by(direction, fieldName);
        PageRequest pageRequest = PageRequest.of(page, size, sort);
        Page<Archive> pageGenre;
        if (value != null && !value.equals("")) {
            ArchiveSpecification specification = new ArchiveSpecification(value);
            pageGenre = archiveRepository.findAll((Specification<Archive>) specification, pageRequest);
        } else {
            pageGenre = archiveRepository.findAll(pageRequest);
        }
        return new DataResponse<ArchiveRespons>(pageGenre.stream().map(ArchiveRespons::new).collect(Collectors.toList()), pageGenre);
    }
}
