package roman.pidkostelny.dealer.specification;

import org.springframework.data.jpa.domain.Specification;

import roman.pidkostelny.dealer.dto.request.ArchiveFilterRequest;
import roman.pidkostelny.dealer.entity.Archive;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

public class ArchiveSpecification implements Specification<Archive> {
    private ArchiveFilterRequest filter;

    public ArchiveSpecification(ArchiveFilterRequest filter) {
        this.filter = filter;
    }

    private String value;

    public ArchiveSpecification(String value) {
        this.value = value;
    }

    private Predicate findByName(Root<Archive> root, CriteriaBuilder criteriaBuilder) {
        return criteriaBuilder.like(root.get("Name"), value);
    }


    @Override
    public Predicate toPredicate(Root<Archive> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
        return criteriaBuilder.or(findByName(root, criteriaBuilder));
    }
}
