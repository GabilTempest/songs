package roman.pidkostelny.dealer.entity;

public enum SongType {
    ROCK, POP, GRAGE;

}
