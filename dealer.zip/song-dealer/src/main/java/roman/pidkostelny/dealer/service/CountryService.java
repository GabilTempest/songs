package roman.pidkostelny.dealer.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import roman.pidkostelny.dealer.dto.request.CountryRequest;
import roman.pidkostelny.dealer.dto.respons.CountryResponse;
import roman.pidkostelny.dealer.dto.respons.DataResponse;
import roman.pidkostelny.dealer.entity.Country;
import roman.pidkostelny.dealer.exception.WrongInp;
import roman.pidkostelny.dealer.repository.CountryRepository;
import roman.pidkostelny.dealer.specification.CountrySpecification;

import java.util.stream.Collectors;

@Service
public class CountryService {

    @Autowired
    private CountryRepository countryRepository;


    public CountryResponse save(CountryRequest countryRequest) throws WrongInp {
        return new CountryResponse(countryRequestToCountry(null, countryRequest));
    }


    public CountryResponse update(Long id, CountryRequest countryRequest) throws WrongInp {
        return new CountryResponse(countryRequestToCountry(findOne(id), countryRequest));
    }

    public Country findOne(Long id) throws WrongInp {
        return countryRepository.findById(id).orElseThrow(() -> new WrongInp("Country with id " + id + " not exists"));
    }

    private Country countryRequestToCountry(Country country, CountryRequest request) {
        if (country == null) {
            country = new Country();
        }
        country.setName(request.getName());
        return countryRepository.save(country);
    }

    public void delete(Long id) throws WrongInp {
        countryRepository.delete(findOne(id));
    }


    public CountryResponse findOneById(Long id) throws WrongInp {
        return new CountryResponse(findOne(id));
    }

    public DataResponse<CountryResponse> findAll(String value, Integer page, Integer size, String fieldName, Sort.Direction direction) {
        Sort sort = Sort.by(direction, fieldName);
        PageRequest pageRequest = PageRequest.of(page, size, sort);
        Page<Country> pageCountry;
        if (value != null && !value.equals("")) {
            CountrySpecification specification = new CountrySpecification(value);
            pageCountry = countryRepository.findAll(specification, pageRequest);
        } else {
            pageCountry = countryRepository.findAll(pageRequest);
        }
        return new DataResponse<CountryResponse>(pageCountry.stream().map(CountryResponse::new).collect(Collectors.toList()), pageCountry);
    }

}
