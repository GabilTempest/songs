package roman.pidkostelny.dealer.entity;

public enum Role {
    ADMIN,
    USER

}
