package roman.pidkostelny.dealer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;
import roman.pidkostelny.dealer.dto.request.CountryRequest;
import roman.pidkostelny.dealer.dto.request.SongsRequest;
import roman.pidkostelny.dealer.dto.respons.CountryResponse;
import roman.pidkostelny.dealer.dto.respons.DataResponse;
import roman.pidkostelny.dealer.dto.respons.SongsRespons;
import roman.pidkostelny.dealer.entity.Country;
import roman.pidkostelny.dealer.entity.Songs;
import roman.pidkostelny.dealer.exception.WrongInp;
import roman.pidkostelny.dealer.service.CountryService;

import java.util.List;

@RestController
@RequestMapping("/country")
public class CoutryController {
    @Autowired
    private CountryService countryService;

    @GetMapping
    public DataResponse<CountryResponse> getCountry(@RequestParam(required = false) String value,
                                                    @RequestParam Integer page,
                                                    @RequestParam Integer size,
                                                    @RequestParam String sortFieldName,
                                                    @RequestParam Sort.Direction direction) {
        System.out.println("GET ALL Country");
        return countryService.findAll(value, page, size, sortFieldName, direction);
    }

    @PutMapping
    public CountryResponse Update(@RequestParam Long id, @RequestBody CountryRequest countryRequest) throws WrongInp {
        return countryService.update(id, countryRequest);
    }

    @GetMapping("/one")
    public CountryResponse findOne(@RequestParam Long id) throws WrongInp {
        return countryService.findOneById(id);
    }

    @GetMapping("/getOneById")
    public CountryResponse findOneById(@RequestParam Long id) throws WrongInp {
        return countryService.findOneById(id);
    }

    @PostMapping
    public CountryResponse save(@RequestBody CountryRequest countryRequest) throws WrongInp {
        return countryService.save(countryRequest);
    }

    @DeleteMapping("/{id}")
    public void search(@PathVariable Long id) throws WrongInp {
        System.out.println("Delete country by id " + id);
        countryService.delete(id);
    }

    @GetMapping("/{id}")
    public Country getcountryById(@PathVariable Long id) throws WrongInp {
        System.out.println("Get country by id : " + id);
        return countryService.findOne(id);
    }

}


