package roman.pidkostelny.dealer.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HtmlPageController {

    @RequestMapping("/home")
    public String mainPage() {
        return "main.html";
    }

    @RequestMapping("/sing")
    public String singPage() {
        return "sing-in.html";
    }

    @RequestMapping("/Bands")
    public String RockPage() {
        return "Rock.html";
    }

    @RequestMapping("/Nsong")
    public String NsongPage() {
        return "Nsong.html";
    }

    @RequestMapping("/Album")
    public String AlbumPage() {
        return "NAlbum.html";
    }

    @RequestMapping("/Ssong")
    public String SsongPage() {
        return "Ssong.html";
    }

    @RequestMapping("/Ssong2")
    public String Ssong2Page() {
        return "Ssong2.html";
    }

    @RequestMapping("/Nsong2")
    public String Nsong2Page() {
        return "Nsong2.html";
    }

    @RequestMapping("/Nsong3")
    public String Nsong3Page() {
        return "Nsong3.html";
    }

    @RequestMapping("/SOsongs")
    public String SOsongsPage() {
        return "SOsongs.html";
    }

    @RequestMapping("/Rock")
    public String BandsPage() {
        return "BandsIndex.html";
    }

    @RequestMapping("/Songs")
    public String SongsIndexPage() {
        return "Songs.html";
    }

    @RequestMapping("/NAlbum")
    public String NAlbumPage() {
        return "NAlbum.html";
    }

    @RequestMapping("/FALbom")
    public String FALbomPage() {
        return "FALbom.html";
    }

    @RequestMapping("/Bleach")
    public String BleachPage() {
        return "Bleach.html";
    }

    @RequestMapping("/GenreIndex")
    public String GenreIndexPage() {
        return "GenreIndex2.html";
    }

    @RequestMapping("/disco")
    public String DiscoPage() {
        return "Disco.html";
    }

    @RequestMapping("/SongsIndex")
    public String SongsPage() {
        return "Songs.index.html";
    }

    @RequestMapping("/Band")
    public String BandPage() {
        return "Bands.html";
    }

    @RequestMapping("/Pop")
    public String PopPage() {
        return "Pop.html";
    }

    @RequestMapping("/Country")
    public String CountryPage() {
        return "CountryIndex.html";
    }

    @RequestMapping("/Update")
    public String UpdatePage() {
        return "Update-song.html";
    }

    @RequestMapping("/Smells")
    public String SmellsPage() {
        return "Spirit.";
    }

    @RequestMapping("/reGestracja")
    public String reGestracjaPage() {
        return "reGestracja.html";
    }

    @RequestMapping("/Nirvana")
    public String NirvanaPage() {
        return "SAlbum.html";
    }

    @RequestMapping("/SCAlbom")
    public String SCAlbomPage() {
        return "SCAlbom.html";
    }

    @RequestMapping("/Scorpions")
    public String SFAlbomPage() {
        return "SFAlbom.html";
    }

    @RequestMapping("/SystemOfADown")
    public String SOAlbomPage() {
        return "SOAlbom.html";
    }

    @RequestMapping("/Geners")
    public String GenersPage() {
        return "Geners.html";
    }

    @RequestMapping("/Archive")
    public String GenerPage() {
        return "Archive.html";
    }
}

